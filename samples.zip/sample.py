import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, InputLayer
from tensorflow.keras.layers import Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.losses import mean_squared_error
from tensorflow import data as tfdata

# Load datasets
train_data = tfdata.experimental.load('train_data')
valid_data = tfdata.experimental.load('valid_data')

# Shuffle and batch data
n_batch = 5
shuffle_buffer = len(train_data)//5

train_data = train_data.shuffle(shuffle_buffer)
train_data = train_data.batch(len(train_data)//n_batch)
valid_data = valid_data.shuffle(shuffle_buffer)
valid_data = valid_data.batch(len(valid_data)//n_batch)

# Create model
# Create model
model = Sequential(name='sample_model')
model.add(InputLayer(input_shape=(52, 1)))

model.add(LSTM(128, return_sequences=True))
model.add(LSTM(128, return_sequences=True))
model.add(LSTM(128))
model.add(Dense(128))
model.add(Dense(128))

model.add(Dense(52))

opt_adam = Adam(learning_rate=0.0001)
model.compile(optimizer=opt_adam, loss='mse')

model.summary()

# Train model
n_epochs = 30
history = model.fit(train_data, epochs=n_epochs, verbose=2, validation_data=valid_data)
model.save('sample_model.h5')

# Check training performance
loss = history.history['loss']
val_loss = history.history['val_loss']
epochs = [i for i in range(1, n_epochs+1)]

wid = 8
hei = (9/16)*wid
plt.figure(figsize=(wid, hei), dpi=720/hei, facecolor='white')
plt.plot(epochs, loss)
plt.plot(epochs, val_loss)
plt.xlabel('epochs')
plt.ylabel('Loss (mse) [p.u.$^2$]')
plt.title('Training performance')
plt.legend(['Loss', 'Val Loss'])
plt.grid()
plt.tight_layout()
plt.savefig('sample_training_performance.png')

# Sample custom testing
from tensorflow.keras.models import load_model
model = load_model('sample_model.h5')
Xi = np.array([0.021196, 0.0324, 0.047947, 0.049171, 0.101753, 0.143651, 0.175416, 0.241093, 0.279647, 
    0.347947, 0.388621, 0.438977, 0.476201, 0.515669, 0.545172, 0.585968, 0.61219, 0.631767, 0.655174, 
    0.661024, 0.704135, 0.717295, 0.735158, 0.750131, 0.766011, 0.79206, 0.784453, 0.780773, 0.782364, 
    0.789372, 0.774409, 0.629287, 0.775065, 0.730273, 0.720087, 0.709926, 0.682994, 0.662177, 0.637811, 
    0.587391, 0.573263, 0.563042, 0.587147, 0.587835, 0.526477, 0.195742, 0.206819, 0.205879, 0.169963, 
    0.104614, 0.056681, 0.019531
]).reshape(-1, 52, 1)
yi = np.array([0.030658, 0.040972, 0.058045, 0.081514, 0.110395, 0.162851, 0.189172, 0.257657, 0.295849, 
    0.353663, 0.406323, 0.442387, 0.476738, 0.520716, 0.54672, 0.592199, 0.616068, 0.643833, 0.674501, 
    0.708306, 0.515263, 0.3666, 0.831338, 0.505942, 0.547648, 0.170246, 0.282644, 0.432785, 0.734085, 
    0.807913, 0.850276, 0.780368, 0.425808, 0.739751, 0.765601, 0.654127, 0.647661, 0.336103, 0.086199, 
    0.661106, 0.55612, 0.334685, 0.099821, 0.396465, 0.114928, 0.09965, 0.308388, 0.307917, 0.065491, 
    0.04482, 0.036525, 0.036526
]).reshape(-1,)
y_hat = model.predict(Xi).reshape(-1,)

rmse = np.sqrt(np.mean((yi - y_hat)**2))

t = np.linspace(6, 18.75, 52)
wid = 8
hei = (9/16)*wid
plt.figure(figsize=(wid, hei), dpi=720/hei, facecolor='white')
plt.plot(t, yi, '-o')
plt.plot(t, y_hat, '-x')
plt.xlabel('Time')
plt.ylabel('PV Power [p.u.]')
plt.title('Model performance (RMSE: {:,.4f} [p.u.])'.format(rmse))
plt.legend(['True', 'Predicted'])
plt.grid()
plt.tight_layout()
plt.savefig('sample_testing_performance.png')